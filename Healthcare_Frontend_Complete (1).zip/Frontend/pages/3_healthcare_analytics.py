import pandas as pd
import plotly.express as px
import streamlit as st
from services.api_client import get_analytics,APIError
st.title("Healthcare Analytics"); st.caption("Diagnosis and medication utilization insights")
limit=st.slider("Top records",5,30,10)
try:
    diagnoses=get_analytics("diagnoses",limit=limit); medications=get_analytics("medications",limit=limit)
    ddf=pd.DataFrame(diagnoses); mdf=pd.DataFrame(medications)
    left,right=st.columns(2)
    with left:
        st.subheader("Top Diagnoses"); st.plotly_chart(px.bar(ddf.sort_values("total_records"),x="total_records",y="diagnosis_code",orientation="h"),use_container_width=True); st.dataframe(ddf,use_container_width=True,hide_index=True)
    with right:
        st.subheader("Top Medications"); st.plotly_chart(px.bar(mdf.sort_values("total_records"),x="total_records",y="medication",orientation="h"),use_container_width=True); st.dataframe(mdf,use_container_width=True,hide_index=True)
    st.info("These charts summarize the source dataset and are intended for operational/educational analytics, not clinical decision-making.")
except APIError as e: st.error(str(e))
