import pandas as pd
import streamlit as st
from services.api_client import list_users,create_user,update_user,APIError
if st.session_state.get("role")!="Admin": st.error("Administrator access required."); st.stop()
st.title("User Administration"); st.caption("Create accounts, assign roles and manage access")
try: st.dataframe(pd.DataFrame(list_users()),use_container_width=True,hide_index=True)
except APIError as e: st.error(str(e))
st.divider(); left,right=st.columns(2)
with left:
    st.subheader("Create User")
    with st.form("create_user",clear_on_submit=True):
        username=st.text_input("Username"); password=st.text_input("Temporary password",type="password",help="Minimum 12 characters"); role=st.selectbox("Role",["Healthcare Staff","Analyst","Admin"])
        if st.form_submit_button("Create user",type="primary",use_container_width=True):
            try: create_user({"username":username.strip(),"password":password,"role":role}); st.success("User created.")
            except APIError as e: st.error(str(e))
with right:
    st.subheader("Change Access")
    with st.form("change_user"):
        uid=st.number_input("User ID",min_value=1,step=1); role=st.selectbox("New role",["Admin","Healthcare Staff","Analyst"]); active=st.selectbox("Account status",["Active","Inactive"])
        if st.form_submit_button("Apply changes",use_container_width=True):
            try: update_user(int(uid),{"role":role,"is_active":active=="Active"}); st.success("User access updated.")
            except APIError as e: st.error(str(e))
