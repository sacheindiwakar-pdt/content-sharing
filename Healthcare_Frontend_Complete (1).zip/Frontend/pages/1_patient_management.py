import pandas as pd
import streamlit as st
from services.api_client import list_patients,get_patient,create_patient,update_patient,APIError
if st.session_state.get("role") not in ("Admin","Healthcare Staff"): st.error("Access denied."); st.stop()
st.title("Patient Management"); st.caption("Search, register and update patient master records")
search,refresh=st.columns([4,1])
with search: patient_id=st.text_input("Patient number",placeholder="Enter exact patient number")
with refresh: st.write(""); st.write(""); refresh_clicked=st.button("Refresh list",use_container_width=True)
try:
    if patient_id:
        try: st.dataframe(pd.DataFrame([get_patient(int(patient_id))]),use_container_width=True,hide_index=True)
        except (ValueError,APIError) as e: st.warning(str(e))
    else: st.dataframe(pd.DataFrame(list_patients(50,0)),use_container_width=True,hide_index=True)
except APIError as e: st.error(str(e))
st.divider(); c1,c2=st.columns(2)
with c1:
    st.subheader("Register Patient")
    with st.form("new_patient",clear_on_submit=True):
        pid=st.number_input("Patient number",min_value=1,step=1); race=st.text_input("Race"); gender=st.text_input("Gender")
        if st.form_submit_button("Create patient",type="primary",use_container_width=True):
            try: create_patient({"patient_nbr":int(pid),"race":race or None,"gender":gender or None}); st.success("Patient created.")
            except APIError as e: st.error(str(e))
with c2:
    st.subheader("Update Patient")
    with st.form("update_patient"):
        upid=st.number_input("Patient number to update",min_value=1,step=1,key="upid"); race=st.text_input("New race (optional)"); gender=st.text_input("New gender (optional)")
        if st.form_submit_button("Update patient",use_container_width=True):
            payload={k:v for k,v in {"race":race,"gender":gender}.items() if v}
            if not payload: st.warning("Enter at least one new value.")
            else:
                try: update_patient(int(upid),payload); st.success("Patient updated.")
                except APIError as e: st.error(str(e))
