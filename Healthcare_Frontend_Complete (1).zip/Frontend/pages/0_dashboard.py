import streamlit as st
from services.api_client import get_analytics_overview,get_analytics,APIError
from components.dashboard import render_dashboard
try:
    with st.spinner("Loading healthcare analytics..."):
        render_dashboard(get_analytics_overview(),get_analytics("admissions"),get_analytics("readmissions"),get_analytics("length-of-stay"))
except APIError as e: st.error(str(e))
