import pandas as pd
import streamlit as st
from services.api_client import list_encounters,get_encounter,create_encounter,update_encounter,get_reference,APIError
if st.session_state.get("role") not in ("Admin","Healthcare Staff"): st.error("Access denied."); st.stop()
st.title("Encounter Management"); st.caption("Search, create and update inpatient encounter records")
q1,q2=st.columns(2)
with q1: encounter_id=st.text_input("Encounter ID search")
with q2: patient_filter=st.text_input("Patient number filter")
try:
    if encounter_id: data=[get_encounter(int(encounter_id))]
    else: data=list_encounters(50,0,int(patient_filter) if patient_filter else None)
    st.dataframe(pd.DataFrame(data),use_container_width=True,hide_index=True)
except (ValueError,APIError) as e: st.warning(str(e))
try:
    admissions=get_reference("admission-types"); discharges=get_reference("discharge-dispositions"); sources=get_reference("admission-sources")
except APIError as e: st.error(str(e)); st.stop()
def options(rows): return {f"{r['id']} - {r.get('description') or 'Unknown'}":r['id'] for r in rows}
ao,do,so=options(admissions),options(discharges),options(sources)
st.divider(); tab1,tab2=st.tabs(["Create Encounter","Update Encounter"])
with tab1:
    with st.form("create_enc"):
        a,b,c=st.columns(3)
        eid=a.number_input("Encounter ID",min_value=1,step=1); pid=b.number_input("Patient number",min_value=1,step=1); age=c.text_input("Age",placeholder="[50-60)")
        a,b,c=st.columns(3); at=a.selectbox("Admission type",list(ao)); dd=b.selectbox("Discharge disposition",list(do)); src=c.selectbox("Admission source",list(so))
        a,b,c=st.columns(3); stay=a.number_input("Time in hospital",min_value=0,step=1); labs=b.number_input("Lab procedures",min_value=0,step=1); meds=c.number_input("Number medications",min_value=0,step=1)
        a,b,c=st.columns(3); proc=a.number_input("Procedures",min_value=0,step=1); diagnoses=b.number_input("Number diagnoses",min_value=0,step=1); readm=c.selectbox("Readmitted",["NO",">30","<30"])
        if st.form_submit_button("Create encounter",type="primary",use_container_width=True):
            payload={"encounter_id":int(eid),"patient_nbr":int(pid),"age":age or None,"admission_type_id":ao[at],"discharge_disposition_id":do[dd],"admission_source_id":so[src],"time_in_hospital":int(stay),"payer_code":None,"medical_specialty":None,"num_lab_procedures":int(labs),"num_procedures":int(proc),"num_medications":int(meds),"number_outpatient":0,"number_emergency":0,"number_inpatient":0,"number_diagnoses":int(diagnoses),"change":None,"diabetesMed":None,"readmitted":readm,"weight":None,"max_glu_serum":None,"A1Cresult":None}
            try: create_encounter(payload); st.success("Encounter created.")
            except APIError as e: st.error(str(e))
with tab2:
    st.info("PATCH updates only the fields you provide; existing values remain unchanged.")
    with st.form("patch_enc"):
        eid=st.number_input("Encounter ID to update",min_value=1,step=1,key="ueid")
        a,b,c=st.columns(3); stay=a.text_input("New time in hospital"); readm=b.selectbox("New readmission status",["No change","NO",">30","<30"]); specialty=c.text_input("New medical specialty")
        if st.form_submit_button("Update encounter",use_container_width=True):
            payload={}
            if stay.strip():
                try: payload["time_in_hospital"]=int(stay)
                except ValueError: st.error("Time in hospital must be an integer."); st.stop()
            if readm!="No change": payload["readmitted"]=readm
            if specialty.strip(): payload["medical_specialty"]=specialty.strip()
            if not payload: st.warning("Provide at least one field to update.")
            else:
                try: update_encounter(int(eid),payload); st.success("Encounter updated.")
                except APIError as e: st.error(str(e))
