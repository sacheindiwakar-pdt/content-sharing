import os
import requests
import streamlit as st
from dotenv import load_dotenv

load_dotenv()
API_URL = os.getenv("API_BASE_URL", "http://127.0.0.1:8000").rstrip("/")

class APIError(Exception):
    pass

def _headers():
    token = st.session_state.get("access_token")
    return {"Authorization": f"Bearer {token}"} if token else {}

def request(method, path, *, params=None, json=None, data=None, auth=True, timeout=15):
    headers = _headers() if auth else {}
    try:
        r = requests.request(method, f"{API_URL}{path}", params=params, json=json, data=data, headers=headers, timeout=timeout)
    except requests.RequestException as e:
        raise APIError(f"Cannot connect to FastAPI at {API_URL}") from e
    if r.status_code == 401:
        raise APIError("Authentication failed or session expired. Please sign in again.")
    if r.status_code == 403:
        raise APIError("Access denied for your role.")
    if not r.ok:
        try: detail = r.json().get("detail", r.text)
        except Exception: detail = r.text
        raise APIError(f"{r.status_code}: {detail}")
    return r.json() if r.content else None

def login(username, password):
    return request("POST", "/auth/login", data={"username": username, "password": password}, auth=False)
def get_me(): return request("GET", "/auth/me")
def get_analytics_overview(): return request("GET", "/analytics/overview")
def get_analytics(endpoint, **params): return request("GET", f"/analytics/{endpoint}", params=params or None)
def list_patients(limit=50, offset=0): return request("GET", "/patients", params={"limit":limit,"offset":offset})
def get_patient(patient_nbr): return request("GET", f"/patients/{patient_nbr}")
def create_patient(payload): return request("POST", "/patients", json=payload)
def update_patient(patient_nbr, payload): return request("PATCH", f"/patients/{patient_nbr}", json=payload)
def list_encounters(limit=50, offset=0, patient_nbr=None):
    p={"limit":limit,"offset":offset}
    if patient_nbr: p["patient_nbr"]=patient_nbr
    return request("GET", "/encounters", params=p)
def get_encounter(encounter_id): return request("GET", f"/encounters/{encounter_id}")
def create_encounter(payload): return request("POST", "/encounters", json=payload)
def update_encounter(encounter_id, payload): return request("PATCH", f"/encounters/{encounter_id}", json=payload)
def get_reference(name): return request("GET", f"/reference-data/{name}")
def list_users(): return request("GET", "/users")
def create_user(payload): return request("POST", "/users", json=payload)
def update_user(user_id, payload): return request("PATCH", f"/users/{user_id}", json=payload)
