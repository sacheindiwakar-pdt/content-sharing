from pathlib import Path
import streamlit as st
from services.api_client import login, get_me, APIError

st.set_page_config(page_title="Healthcare Intelligence", page_icon="H", layout="wide", initial_sidebar_state="expanded")
ROOT=Path(__file__).parent
with open(ROOT/"assets"/"style.css",encoding="utf-8") as f: st.markdown(f"<style>{f.read()}</style>",unsafe_allow_html=True)

def sign_out():
    for k in ["access_token","role","username","user"]: st.session_state.pop(k,None)
    st.rerun()

def login_screen():
    st.markdown("<div class='login-space'></div>",unsafe_allow_html=True)
    _,mid,_=st.columns([1,1.15,1])
    with mid:
        st.title("Healthcare Intelligence")
        st.caption("Secure Patient Management & Analytics Platform")
        with st.form("login"):
            username=st.text_input("Username")
            password=st.text_input("Password",type="password")
            submit=st.form_submit_button("Sign in",use_container_width=True,type="primary")
        if submit:
            try:
                result=login(username.strip(),password)
                st.session_state.access_token=result["access_token"]
                me=get_me()
                st.session_state.user=me
                st.session_state.username=me["username"]
                st.session_state.role=me["role"]
                st.rerun()
            except APIError as e: st.error(str(e))
    st.stop()

if not st.session_state.get("access_token"): login_screen()
try:
    if "user" not in st.session_state:
        me=get_me(); st.session_state.user=me; st.session_state.username=me["username"]; st.session_state.role=me["role"]
except APIError:
    for k in ["access_token","role","username","user"]: st.session_state.pop(k,None)
    st.rerun()

role=st.session_state.role
with st.sidebar:
    st.title("Healthcare")
    st.caption("PATIENT MANAGEMENT PLATFORM")
    st.divider()
    st.write(f"**{st.session_state.username}**")
    st.caption(role)
    st.divider()
    if st.button("Sign out",use_container_width=True): sign_out()

pages=[st.Page("pages/0_dashboard.py",title="Dashboard",icon=":material/dashboard:",default=True),
       st.Page("pages/3_healthcare_analytics.py",title="Healthcare Analytics",icon=":material/monitoring:")]
if role in ("Admin","Healthcare Staff"):
    pages.insert(1,st.Page("pages/1_patient_management.py",title="Patient Management",icon=":material/patient_list:"))
    pages.insert(2,st.Page("pages/2_encounter_management.py",title="Encounter Management",icon=":material/clinical_notes:"))
if role=="Admin": pages.append(st.Page("pages/4_user_administration.py",title="User Administration",icon=":material/admin_panel_settings:"))
st.navigation(pages,position="sidebar").run()
