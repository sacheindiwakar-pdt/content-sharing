def test_admin_authentication(test_client,admin_headers):
    r=test_client.get("/auth/me",headers=admin_headers)
    assert r.status_code==200
    assert r.json()["role"]=="Admin"
    assert r.json()["is_active"] is True
def test_auth_without_token(test_client): assert test_client.get("/auth/me").status_code==401
def test_invalid_token(test_client):
    assert test_client.get("/auth/me",headers={"Authorization":"Bearer invalid-token"}).status_code==401
def test_invalid_login(test_client):
    r=test_client.post("/auth/login",data={"username":"invalid_user_12345","password":"wrong_password_12345"})
    assert r.status_code in (400,401)
