def test_get_medications(test_client,admin_headers,sample_encounter_id):
    r=test_client.get(f"/medications?encounter_id={sample_encounter_id}",headers=admin_headers)
    assert r.status_code==200 and isinstance(r.json(),list)
def test_analyst_no_medications(test_client,analyst_headers,sample_encounter_id):
    assert test_client.get(f"/medications?encounter_id={sample_encounter_id}",headers=analyst_headers).status_code==403
def test_invalid_encounter(test_client,admin_headers):
    assert test_client.get("/medications?encounter_id=999999999999999",headers=admin_headers).status_code in (200,404)
