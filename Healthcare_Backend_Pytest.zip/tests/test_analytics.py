def test_overview(test_client,admin_headers):
    r=test_client.get("/analytics/overview",headers=admin_headers); assert r.status_code==200
    d=r.json(); assert d["total_patients"]>0 and d["total_encounters"]>0 and d["average_length_of_stay"]>0
def test_expected_counts(test_client,admin_headers):
    d=test_client.get("/analytics/overview",headers=admin_headers).json()
    assert d["total_patients"]==71518 and d["total_encounters"]==101766
def test_admissions(test_client,admin_headers): assert test_client.get("/analytics/admissions",headers=admin_headers).status_code==200
def test_readmissions(test_client,admin_headers):
    r=test_client.get("/analytics/readmissions",headers=admin_headers); assert r.status_code==200
    assert r.json()["total_encounters"]==101766 and r.json()["readmitted_encounters"]==46902
def test_los(test_client,admin_headers): assert test_client.get("/analytics/length-of-stay",headers=admin_headers).status_code==200
def test_diagnosis_analytics(test_client,analyst_headers): assert test_client.get("/analytics/diagnoses?limit=10",headers=analyst_headers).status_code==200
def test_medication_analytics(test_client,analyst_headers): assert test_client.get("/analytics/medications?limit=10",headers=analyst_headers).status_code==200
