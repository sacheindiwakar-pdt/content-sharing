import os
import pytest
from fastapi.testclient import TestClient
from dotenv import load_dotenv
from app.main import app

load_dotenv()
client=TestClient(app)

def login(username,password):
    if not username or not password:
        pytest.skip("Test credentials missing")
    r=client.post("/auth/login",data={"username":username,"password":password})
    assert r.status_code==200,r.text
    return {"Authorization":f"Bearer {r.json()['access_token']}"}

@pytest.fixture(scope="session")
def test_client(): return client

@pytest.fixture(scope="session")
def admin_headers(): return login(os.getenv("TEST_ADMIN_USERNAME","admin"),os.getenv("TEST_ADMIN_PASSWORD"))

@pytest.fixture(scope="session")
def staff_headers(): return login(os.getenv("TEST_STAFF_USERNAME"),os.getenv("TEST_STAFF_PASSWORD"))

@pytest.fixture(scope="session")
def analyst_headers(): return login(os.getenv("TEST_ANALYST_USERNAME"),os.getenv("TEST_ANALYST_PASSWORD"))

@pytest.fixture(scope="session")
def sample_patient_id(test_client,admin_headers):
    r=test_client.get("/patients?limit=1",headers=admin_headers)
    assert r.status_code==200 and r.json()
    return r.json()[0]["patient_nbr"]

@pytest.fixture(scope="session")
def sample_encounter_id(test_client,admin_headers):
    r=test_client.get("/encounters?limit=1",headers=admin_headers)
    assert r.status_code==200 and r.json()
    return r.json()[0]["encounter_id"]
