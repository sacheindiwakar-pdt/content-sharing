def test_admission_types(test_client,admin_headers):
    r=test_client.get("/reference/admission_types",headers=admin_headers); assert r.status_code==200 and isinstance(r.json(),list)
def test_discharge_dispositions(test_client,admin_headers):
    r=test_client.get("/reference/discharge_dispositions",headers=admin_headers); assert r.status_code==200 and isinstance(r.json(),list)
def test_admission_sources(test_client,admin_headers):
    r=test_client.get("/reference/admission_sources",headers=admin_headers); assert r.status_code==200 and isinstance(r.json(),list)
