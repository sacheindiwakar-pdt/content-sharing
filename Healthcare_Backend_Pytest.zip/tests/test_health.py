def test_root(test_client): assert test_client.get("/").status_code==200
def test_health(test_client): assert test_client.get("/health").status_code==200
def test_database_health(test_client): assert test_client.get("/health/db").status_code==200
def test_openapi(test_client):
    r=test_client.get("/openapi.json")
    assert r.status_code==200 and "paths" in r.json()
