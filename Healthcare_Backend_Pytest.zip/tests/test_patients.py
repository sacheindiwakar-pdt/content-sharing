def test_list_patients(test_client,admin_headers):
    r=test_client.get("/patients?limit=5",headers=admin_headers)
    assert r.status_code==200 and isinstance(r.json(),list) and len(r.json())<=5
def test_get_patient(test_client,admin_headers,sample_patient_id):
    r=test_client.get(f"/patients/{sample_patient_id}",headers=admin_headers)
    assert r.status_code==200 and r.json()["patient_nbr"]==sample_patient_id
def test_patient_not_found(test_client,admin_headers):
    assert test_client.get("/patients/999999999999999",headers=admin_headers).status_code==404
def test_duplicate_patient(test_client,admin_headers,sample_patient_id):
    r=test_client.post("/patients",headers=admin_headers,json={"patient_nbr":sample_patient_id,"race":"Caucasian","gender":"Male"})
    assert r.status_code==409
def test_patch_patient(test_client,admin_headers,sample_patient_id):
    current=test_client.get(f"/patients/{sample_patient_id}",headers=admin_headers)
    r=test_client.patch(f"/patients/{sample_patient_id}",headers=admin_headers,json={"gender":current.json().get("gender")})
    assert r.status_code==200
