def test_list_encounters(test_client,admin_headers):
    r=test_client.get("/encounters?limit=5",headers=admin_headers)
    assert r.status_code==200 and isinstance(r.json(),list) and len(r.json())<=5
def test_get_encounter(test_client,admin_headers,sample_encounter_id):
    r=test_client.get(f"/encounters/{sample_encounter_id}",headers=admin_headers)
    assert r.status_code==200 and r.json()["encounter_id"]==sample_encounter_id
def test_encounter_not_found(test_client,admin_headers):
    assert test_client.get("/encounters/999999999999999",headers=admin_headers).status_code==404
def test_filter_by_patient(test_client,admin_headers,sample_patient_id):
    r=test_client.get(f"/encounters?patient_nbr={sample_patient_id}&limit=10",headers=admin_headers)
    assert r.status_code==200
    assert all(x["patient_nbr"]==sample_patient_id for x in r.json())
def test_duplicate_encounter(test_client,admin_headers,sample_encounter_id):
    current=test_client.get(f"/encounters/{sample_encounter_id}",headers=admin_headers)
    r=test_client.post("/encounters",headers=admin_headers,json=current.json())
    assert r.status_code==409
def test_patch_encounter(test_client,admin_headers,sample_encounter_id):
    current=test_client.get(f"/encounters/{sample_encounter_id}",headers=admin_headers)
    r=test_client.patch(f"/encounters/{sample_encounter_id}",headers=admin_headers,json={"time_in_hospital":current.json()["time_in_hospital"]})
    assert r.status_code==200
